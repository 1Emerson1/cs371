# pyex2.py - Standard input/output
import sys

for line in sys.stdin:
    sys.stdout.write(line)